/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulapratica3;

/**
 *
 * @author helder
 */
public class ContaCorrenteApp{ 
        
        public static void main(String[] args){
             
            ContaCorrente contacomum = new ContaCorrente(124,542);
            
            ContaCorrente contaespecial = new ContaCorrente(124,549,1000.00f);
            
            
      }
    
}
